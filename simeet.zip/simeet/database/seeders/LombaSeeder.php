<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LombaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('lombas')->insert([
            'foto' => 'simet.jpg',
            'judul' => 'basket',
            'juklak_juknis' => 'kamu nanya',
            'kontak' => '085880301679',

        ]);
    }
}
