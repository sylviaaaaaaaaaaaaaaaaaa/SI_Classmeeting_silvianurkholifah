<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class JadwalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('jadwals')->insert([
            'nama_lomba' => 'BolaBasket',
            'nama_kelas' => 'XI PPLG 2 VS XI PPLG 3',
            'waktu' => '08.30-08.50',
            'hasil' => 'XI PPLG 2',
        ]);
    }
}
