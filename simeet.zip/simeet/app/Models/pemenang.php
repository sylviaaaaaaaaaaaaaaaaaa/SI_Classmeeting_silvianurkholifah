<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class pemenang extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function detailwinner($id)
    {
        return DB::table('pemenang')->where('id', $id)->first();
    }
}
