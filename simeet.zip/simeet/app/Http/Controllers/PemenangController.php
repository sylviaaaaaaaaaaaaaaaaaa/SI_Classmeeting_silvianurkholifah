<?php

namespace App\Http\Controllers;

use App\Models\Pemenang;
use Illuminate\Http\Request;

class PemenangController extends Controller
{
    public function index (Request $request){
        if($request->has('search')){
            $data = Pemenang::where('nama_perlombaan', 'LIKE', '%' .$request->search.'%')->paginate(3);
        }else{
            $data = Pemenang::paginate(3);
        } 
       
    return view('pemenang', compact('data'));
}

    public function tambahwinner(){
        return view('tambahwinner');
    }

    public function insertwinner(Request $request){
        $this->validate($request,[
            'nama_perlombaan' => 'required',
            'juara_satu' => 'required',
            'juara_dua' => 'required',
            'juara_tiga' => 'required',
            'foto_lomba' => 'required |mimes:jpg,png,jpeg',
        ],[ 
            'nama_perlombaan.required'=> 'nama tidak boleh kosong',
            'juara_satu.required'=> 'winner tidak boleh kosong',
            'juara_dua.required'=> 'winner tidak boleh kosong' ,
            'juara_tiga.required'=> 'winner tidak boleh kosong' ,
            'foto_lomba.required'=> 'foto tidak boleh kosong',
            'foto_lomba.mimes'=> 'jenis file tidak mendukung',
        ]);
       $data = Pemenang::create($request->all());
       if($request->hasFile('foto_lomba')){
        $request->file('foto_lomba')->move('fotowinner/', $request->file('foto_lomba')->getClientOriginalName());
        $data->foto_lomba = $request->file('foto_lomba')->getClientOriginalName();
        $data->save();
       }
       return redirect()->route('pemenang')->with('success', 'data berhasil ditambahkan');
    }

    public function edit($id){
        $data = Pemenang::find($id);
        //dd($data);
        return view('edit', compact('data'));
    }

    public function updatewinner(Request $request, $id){
        $this->validate($request,[
           'nama_perlombaan' => 'required',
           'juara_satu' => 'required',
           'juara_dua' => 'required',
           'juara_tiga' => 'required',
           'foto_lomba' => 'required |mimes:jpg,png,jpeg',
       ],[ 
           'nama_perlombaan.required'=> 'nama tidak boleh kosong',
           'juara_satu.required'=> 'winner tidak boleh kosong',
           'juara_dua.required'=> 'winner tidak boleh kosong' ,
           'juara_tiga.required'=> 'winner tidak boleh kosong' ,
           'foto_lomba.required'=> 'foto tidak boleh kosong',
           'foto_lomba.mimes'=> 'jenis file tidak mendukung',
       ]);
        $data = Pemenang::find($id);
        $data->update($request->all());
        if($request->hasFile('foto_lomba')){
            $request->file('foto_lomba')->move('fotowinner/', $request->file('foto_lomba')->getClientOriginalName());
            $data->foto_lomba = $request->file('foto_lomba')->getClientOriginalName();
            $data->save();
           }
        return redirect()->route('pemenang')->with('success', 'data berhasil diubah');
    }


    public function detailwinner($id)
    {
        $data = Pemenang::findOrFail($id);
         return view ('detailwinner', compact ('data'));
    }

    public function destroy($id){
        Pemenang::destroy($id);
        return redirect()->route('pemenang')->with('success', 'data berhasil dihapus');
    }
}
