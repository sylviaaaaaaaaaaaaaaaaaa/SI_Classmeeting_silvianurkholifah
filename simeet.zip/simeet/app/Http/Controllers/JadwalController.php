<?php

namespace App\Http\Controllers;

use App\Models\Jadwal;
use Illuminate\Http\Request;

class JadwalController extends Controller
{
    public function index (Request $request){
        if($request->has('search')){
            $data = Jadwal::where('nama_lomba', 'LIKE', '%' .$request->search.'%')
            ->orWhere('nama_kelas', 'LIKE', '%' .$request->search.'%')
            ->orWhere('waktu', 'LIKE', '%' .$request->search.'%')->paginate(5);
        }else{
            $data = Jadwal::paginate(5);
        }
       
        return view('datajadwal', compact('data'));
    }

    public function tambah(){
        return view('tambah');
    }

    public function insert(Request $request){
        $this->validate($request,[
            'nama_lomba' => 'required',
            'nama_kelas' => 'required',
            'hari' => 'required',
            'waktu' => 'required',
        ],[
            'nama_lomba.required'=> 'nama lomba tidak boleh kosong',
            'nama_kelas.required'=> 'kelas tidak boleh kosong',
            'hari.required'=> 'kelas tidak boleh kosong',
            'waktu.required'=> 'waktu tidak boleh kosong',
        ]);
       $data = Jadwal::create($request->all());
        $data->save();
       return redirect()->route('datajadwal')->with('success', 'data berhasil ditambahkan');
    }

    public function tampilkan($id){
        $data = Jadwal::find($id);
        //dd($data);
        return view('tampil', compact('data'));
    }

    public function update(Request $request, $id){
        $this->validate($request,[
            'nama_lomba' => 'required',
            'nama_kelas' => 'required',
            'hari' => 'required',
            'waktu' => 'required',
        ],[ 
            'nama_lomba.required'=> 'nama lomba tidak boleh kosong',
            'nama_kelas.required'=> 'kelas tidak boleh kosong',
            'hari.required'=> 'kelas tidak boleh kosong',
            'waktu.required'=> 'waktu tidak boleh kosong',
        ]);
        $data = Jadwal::find($id);
        $data->update($request->all());

        return redirect()->route('datajadwal')->with('success', 'data berhasil diubah');
    }

    public function destroy($id){
        Jadwal::destroy($id);
        return redirect()->route('datajadwal')->with('success', 'data berhasil dihapus');
    }

    public function cetakjadwal()
    {
        $data = Jadwal::all();
        return view('cetakjadwal', compact('data'));
    }
   
}
