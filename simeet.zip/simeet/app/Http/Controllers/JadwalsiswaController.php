<?php

namespace App\Http\Controllers;

use App\Models\Jadwal;
use Illuminate\Http\Request;

class JadwalsiswaController extends Controller
{
        public function index (Request $request){
            if($request->has('search')){
                $data = Jadwal::where('nama_lomba', 'LIKE', '%' .$request->search.'%')->paginate(5);
            }else{
                $data = Jadwal::paginate(5);
            } 
           
        return view('jadwalsiswa', compact('data'));
    }

    
}
