<?php

namespace App\Http\Controllers;

use App\Models\daftar;
use Illuminate\Http\Request;

class DaftarController extends Controller
{
    public function index (Request $request){
        if($request->has('search')){
            $data = Daftar::where('nama', 'LIKE', '%' .$request->search.'%')
            ->orWhere('nama_kelas', 'LIKE', '%' .$request->search.'%')
            ->orWhere('jenis_lomba', 'LIKE', '%' .$request->search.'%')->paginate(5);
        }else{
            $data = Daftar::paginate(5);
        }
       
        return view('daftar', compact('data'));
    }

    public function create(){
        return view('create');
    }

    public function tambahpeserta(){
        return view('tambahpeserta');
    }

    public function insertdata(Request $request){
        $this->validate($request,[
            'nama' => 'required',
            'nama_kelas' => 'required',
            'jenis_lomba' => 'required',
        ],[
            'nama.required'=> 'nama lomba tidak boleh kosong',
            'nama_kelas.required'=> 'kelas tidak boleh kosong',
            'jenis_lomba.required'=> 'kelas tidak boleh kosong',
            
        ]);
        $daftar = new Daftar([
            'nama' => $request->input('nama'),
            'nama_kelas' => $request->input('nama_kelas'),
            'jenis_lomba' => $request->input('jenis_lomba'),
        ]);
        $daftar->save();
        return redirect('/home')->with('success', 'Sukses Pendaftaran');
    }

    public function cetakpeserta()
    {
        $data = Daftar::all();
        return view('cetakpeserta', compact('data'));
    }

    
}