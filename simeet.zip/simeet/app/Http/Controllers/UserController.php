<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function index()
    {
        $data = DB::table('users')->paginate(5);

        return view('user', compact('data'));
    }
 
    public function destroy($id){
        User::destroy($id);
        return redirect()->route('user')->with('success', 'data berhasil dihapus');
    }

    
}
