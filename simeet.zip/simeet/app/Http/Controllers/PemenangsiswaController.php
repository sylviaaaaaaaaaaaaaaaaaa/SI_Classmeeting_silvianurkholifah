<?php

namespace App\Http\Controllers;

use App\Models\Pemenang;
use Illuminate\Http\Request;

class PemenangsiswaController extends Controller
{
    public function index (){
        $pemenang = Pemenang::All();
         return view('pemenangsiswa',[
             'pemenang'=>$pemenang
         ]);
     }
 
     public function winnerdetail($id)
     {
         $data = Pemenang::findOrFail($id);
          return view ('winnerdetail', compact ('data'));
     }
}
