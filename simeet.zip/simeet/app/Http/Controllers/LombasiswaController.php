<?php

namespace App\Http\Controllers;

use App\Models\Lomba;
use Illuminate\Http\Request;

class LombasiswaController extends Controller
{
    public function index (){
       $lomba = Lomba::All();
        return view('lombasiswa',[
            'lomba'=>$lomba
        ]);
    }

    public function detailsiswa($id)
    {
        $data = Lomba::findOrFail($id);
         return view ('detailsiswa', compact ('data'));
    }
}
