<?php

namespace App\Http\Controllers;

use App\Models\Lomba;
use Illuminate\Http\Request;

class LombaController extends Controller
{
    public function index (Request $request){
        if($request->has('search')){
            $data = Lomba::where('judul', 'LIKE', '%' .$request->search.'%')
            ->orWhere('juklak_juknis', 'LIKE', '%' .$request->search.'%')
            ->orWhere('kontak', 'LIKE', '%' .$request->search.'%')->paginate(3);
        }else{
            $data = Lomba::paginate(3);
        }
       
        return view('datalomba', compact('data'));
    }

    public function tambahdata(){
        return view('tambahdata');
    }

    public function insertdata(Request $request){
        $this->validate($request,[
            'judul' => 'required',
            'juklak_juknis' => 'required',
            'kontak' => 'required',
            'foto' => 'required |mimes:jpg,png,jpeg',
        ],[ 
            'judul.required'=> 'judul tidak boleh kosong',
            'juklak_juknis.required'=> 'juklak tidak boleh kosong',
            'kontak.required'=> 'kontak tidak boleh kosong' ,
            'foto.required'=> 'foto tidak boleh kosong',
            'foto.mimes'=> 'jenis file tidak mendukung',
        ]);
       $data = Lomba::create($request->all());
       if($request->hasFile('foto')){
        $request->file('foto')->move('fotolomba/', $request->file('foto')->getClientOriginalName());
        $data->foto = $request->file('foto')->getClientOriginalName();
        $data->save();
       }
       return redirect()->route('datalomba')->with('success', 'data berhasil ditambahkan');
    }

    public function tampilkandata($id){
        $data = Lomba::find($id);
        //dd($data);
        return view('tampildata', compact('data'));
    }

    public function updatedata(Request $request, $id){
        $this->validate($request,[
            'judul' => 'required',
            'juklak_juknis' => 'required',
            'kontak' => 'required',
            'foto' => 'mimes:jpg,png,jpeg',
        ],[ 
            'judul.required'=> 'judul tidak boleh kosong',
            'juklak_juknis.required'=> 'juklak tidak boleh kosong',
            'kontak.required'=> 'kontak tidak boleh kosong' ,
            'foto.required'=> 'foto tidak boleh kosong',
            'foto.mimes'=> 'jenis file tidak mendukung',
        ]);
        $data = Lomba::find($id);
        $data->update($request->all());
        if($request->hasFile('foto')){
            $request->file('foto')->move('fotolomba/', $request->file('foto')->getClientOriginalName());
            $data->foto = $request->file('foto')->getClientOriginalName();
            $data->save();
           }
        return redirect()->route('datalomba')->with('success', 'data berhasil diubah');
    }

    public function destroy($id){
        Lomba::destroy($id);
        return redirect()->route('datalomba')->with('success', 'data berhasil dihapus');
    }

    public function detail($id)
    {
        $data = Lomba::findOrFail($id);
         return view ('detail', compact ('data'));
    }

}



