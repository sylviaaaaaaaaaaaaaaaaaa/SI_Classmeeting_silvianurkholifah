<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LombaController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\DaftarController;
use App\Http\Controllers\LombasiswaController;
use App\Http\Controllers\JadwalsiswaController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PemenangController;
use App\Http\Controllers\PemenangsiswaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});



Auth::routes();

//untuk data lomba
Route::get('/datalomba', [LombaController::class, 'index'])->name('datalomba');
Route::get('/tambahdata', [LombaController::class, 'tambahdata'])->name('tambahdata');
Route::post('/insertdata', [LombaController::class, 'insertdata'])->name('insertdata');
Route::get('/tampilkandata/{id}', [LombaController::class, 'tampilkandata'])->name('tampilkandata');
Route::post('/updatedata/{id}', [LombaController::class, 'updatedata'])->name('updatedata');
Route::delete('/hapus/{id}', [LombaController::class, 'destroy'])->name('destroy');
Route::get('/detail/{id}', [LombaController::class, 'detail'])->name('detail');

//pemenang lomba
Route::get('/pemenang', [PemenangController::class, 'index'])->name('pemenang');
Route::get('/tambahwinner', [PemenangController::class, 'tambahwinner'])->name('tambahwinner');
Route::post('/insertwinner', [PemenangController::class, 'insertwinner'])->name('insertwinner');
Route::get('/edit/{id}', [PemenangController::class, 'edit'])->name('edit');
Route::post('/updatewinner/{id}', [PemenangController::class, 'updatewinner'])->name('updatewinner');
Route::get('/detailwinner/{id}', [PemenangController::class, 'detailwinner'])->name('detailwinner');
Route::delete('/push/{id}', [PemenangController::class, 'destroy'])->name('destroy');

//untuk jadwal
Route::get('/datajadwal', [JadwalController::class, 'index'])->name('datajadwal');
Route::get('/tambah', [JadwalController::class, 'tambah'])->name('tambah');
Route::post('/insert', [JadwalController::class, 'insert'])->name('insert');
Route::get('/tampilkan/{id}', [JadwalController::class, 'tampilkan'])->name('tampilkan');
Route::post('/update/{id}', [JadwalController::class, 'update'])->name('update');
Route::delete('/delete/{id}', [JadwalController::class, 'destroy'])->name('destroy');
Route::get('/cetakjadwal', [JadwalController::class, 'cetakJadwal'])->name('cetakjadwal');


//untuk daftar
Route::get('/daftar', [DaftarController::class, 'index'])->name('daftar');
Route::get('/tambahpeserta', [DaftarController::class, 'tambahpeserta'])->name('tambahpeserta');
Route::post('/daftar', [DaftarController::class, 'insertdata'])->name('daftar');
Route::get('/daftars/create','DaftarController@create');
Route::get('/cetakpeserta', [DaftarController::class, 'cetakPeserta'])->name('cetakpeserta');

//untuk data lomba siswa
Route::get('/lombasiswa', [LombasiswaController::class, 'index'])->name('lombasiswa');
Route::get('/detailsiswa/{id}', [LombasiswaController::class, 'detailsiswa'])->name('detailsiswa');

//untuk data pemenang siswa
Route::get('/pemenangsiswa', [PemenangsiswaController::class, 'index'])->name('pemenangsiswa');
Route::get('/winnerdetail/{id}', [PemenangsiswaController::class, 'winnerdetail'])->name('winnerdetail');


//untuk data jadwal siswa
Route::get('/jadwalsiswa', [JadwalsiswaController::class, 'index'])->name('jadwalsiswa');

//untuk data user
Route::get('/user', [UserController::class, 'index'])->name('user');
Route::delete('/remove/{id}', [UserController::class, 'destroy'])->name('destroy');

Auth::routes();

Route::group(['middleware' => ['auth','ceklevel:admin,siswa']], function(){
    Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/logout', function (){
    \Auth::logout();
    return redirect('/');
});
});



