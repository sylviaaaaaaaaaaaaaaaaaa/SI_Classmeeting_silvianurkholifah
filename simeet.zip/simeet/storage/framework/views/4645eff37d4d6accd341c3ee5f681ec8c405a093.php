<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!----======== CSS ======== -->
    
    <link rel="stylesheet" href="/css/app.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/trix.css')); ?>">
        <script type="text/javascript" src="/js/trix.js"></script>
        <link rel="stylesheet" type="text/css" href="https://unpkg.com/trix@2.0.0/dist/trix.css">
        <script type="text/javascript" src="https://unpkg.com/trix@2.0.0/dist/trix.umd.min.js"></script>
    <!----===== Boxicons CSS ===== -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<div class="sidebar">
    <div class="logo-details">

        <i class='bx bxl-stripe'></i>
        <i class='bx bx-menu' id="btn"></i>
    </div>
    <ul class="nav-list">
        <li>
            <i class='bx bx-search'></i>
            <input type="text" placeholder="Search...">
            <span class="tooltip">Search</span>
        </li>
        <li>
            <a href="/home">
                <i class='bx bx-grid-alt'></i>
                <span class="links_name">Dashboard</span>
            </a>
            <span class="tooltip">Dashboard</span>
        </li>
        <li>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/user">
                    <i class='bx bx-user'></i>
                    <span class="links_name">User</span>
                </a>
                <span class="tooltip">User</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/datalomba">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Data Lomba</span>
                </a>
                <span class="tooltip">Data Lomba</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'siswa'): ?>
                <a href="/lombasiswa">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Data Lomba</span>
                </a>
                <span class="tooltip">Data Lomba</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/datajadwal">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Data Jadwal</span>
                </a>
                <span class="tooltip">Data Jadwal</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'siswa'): ?>
                <a href="/tambahpeserta">
                    <i class='bx bx-cart-alt'></i>
                    <span class="links_name">Pendaftaran</span>
                </a>
                <span class="tooltip">Pendaftaran</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'siswa'): ?>
                <a href="/jadwalsiswa">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Data Jadwal</span>
                </a>
                <span class="tooltip">Data Jadwal</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/pemenang">
                    <i class="bi bi-trophy"></i>
                    <span class="links_name">Pemenang</span>
                </a>
                <span class="tooltip">Pemenang</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'siswa'): ?>
                <a href="/pemenangsiswa">
                    <i class="bi bi-trophy"></i>
                    <span class="links_name">Pemenang</span>
                </a>
                <span class="tooltip">Pemenang</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/daftar">
                    <i class='bx bx-task'></i>
                    <span class="links_name">Data Peserta</span>
                </a>
                <span class="tooltip">Data Peserta</span>
        </li>
        <li>
            <?php endif; ?>
            <a href="<?php echo e(route('logout')); ?>">
                <i class='bx bx-log-out' id="log_out"></i>
                <span class="links_name">Logout</span>
            </a>
            <span class="tooltip">Logout</span>
        </li>
        <li>

        </li>
    </ul>
</div>
<section class="home-section">
        <h1 class="text-center mb-4">Pemenang Lomba</h1>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-15 mt-4 mb-4">

                    <div class="row justify-content-center">
                        <div class="col-10">
                            <div class="card">
                                <div class="card-body">
                                    <form action="/updatewinner/<?php echo e($data->id); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Foto</label>
                                            <input type="file" name="foto_lomba"
                                                class="form-control <?php $__errorArgs = ['foto_lomba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="<?php echo e(old('foto_lomba', $data->foto_lomba)); ?>">
                                            <?php $__errorArgs = ['foto_lomba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Nama Lomba</label>
                                            <input type="text" name="nama_perlombaan"
                                                class="form-control <?php $__errorArgs = ['nama_perlombaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="<?php echo e(old('nama_perlombaan', $data->nama_perlombaan)); ?>">
                                            <?php $__errorArgs = ['nama_perlombaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Winner 1</label>
                                            <input type="text" name="juara_satu"
                                                class="form-control  <?php $__errorArgs = ['juara_satu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="<?php echo e(old('juara_satu', $data->juara_satu)); ?>">
                                            <?php $__errorArgs = ['juara_satu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Winner 2</label>
                                            <input type="text" name="juara_dua"
                                                class="form-control  <?php $__errorArgs = ['juara_dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="<?php echo e(old('juara_dua', $data->juara_dua)); ?>">
                                            <?php $__errorArgs = ['juara_dua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Winner 3</label>
                                            <input type="text" name="juara_tiga"
                                                class="form-control  <?php $__errorArgs = ['juara_tiga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="<?php echo e(old('juara_tiga', $data->juara_tiga)); ?>">
                                            <?php $__errorArgs = ['juara_tiga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <button type="submit" class="btn btn-primary">Edit</button>
                                        <a href="/pemenang" class="btn btn-warning">Kembali</a>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <script>
                let sidebar = document.querySelector(".sidebar");
                let closeBtn = document.querySelector("#btn");
                let searchBtn = document.querySelector(".bx-search");
            
                closeBtn.addEventListener("click", () => {
                    sidebar.classList.toggle("open");
                    menuBtnChange(); //calling the function(optional)
                });
            
                searchBtn.addEventListener("click", () => { // Sidebar open when you click on the search iocn
                    sidebar.classList.toggle("open");
                    menuBtnChange(); //calling the function(optional)
                });
            
                // following are the code to change sidebar button(optional)
                function menuBtnChange() {
                    if (sidebar.classList.contains("open")) {
                        closeBtn.classList.replace("bx-menu", "bx-menu-alt-right"); //replacing the iocns class
                    } else {
                        closeBtn.classList.replace("bx-menu-alt-right", "bx-menu"); //replacing the iocns class
                    }
                }
            </script>

                <!-- Optional JavaScript; choose one of the two! -->

                <!-- Option 1: Bootstrap Bundle with Popper -->
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
                    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
                </script>

                <!-- Option 2: Separate Popper and Bootstrap JS -->
                <!--
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
            integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
            integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
        </script>
        -->
    </body>

    </html>
    </div>
    </div>

<?php /**PATH C:\simeet\resources\views/edit.blade.php ENDPATH**/ ?>