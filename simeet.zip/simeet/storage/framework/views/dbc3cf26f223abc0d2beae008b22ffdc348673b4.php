<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!----======== CSS ======== -->
    <link rel="stylesheet" href="css/app.css">

    <!----===== Boxicons CSS ===== -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<div class="sidebar">
    <div class="logo-details">
     
      <i class='bx bxl-stripe'></i>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
          <i class='bx bx-search' ></i>
         <input type="text" placeholder="Search...">
         <span class="tooltip">Search</span>
      </li>
      <li>
        <a href="/home">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
      <li>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/user">
         <i class='bx bx-user' ></i>
         <span class="links_name">User</span>
       </a>
       <span class="tooltip">User</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/datalomba">
        <i class='bx bx-book'></i>
         <span class="links_name">Data Lomba</span>
       </a>
       <span class="tooltip">Data Lomba</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
       <a href="/lombasiswa">
        <i class='bx bx-book'></i>  
         <span class="links_name">Data Lomba</span>
       </a>
       <span class="tooltip">Data Lomba</span>
     </li>
     <li>

      <?php endif; ?>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/datajadwal">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Data Jadwal</span>
       </a>
       <span class="tooltip">Data Jadwal</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
        <a href="/tambahpeserta">
          <i class='bx bx-clipboard'></i>
          <span class="links_name">Pendaftaran</span>
        </a>
        <span class="tooltip">Pendaftaran</span>
      </li>
      <li>
         <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
       <a href="/jadwalsiswa">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Data Jadwal</span>
       </a>
       <span class="tooltip">Data Jadwal</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/pemenang">
        <i class="bi bi-trophy"></i>
         <span class="links_name">Pemenang</span>
       </a>
       <span class="tooltip">Pemenang</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
       <a href="/pemenangsiswa">
        <i class="bi bi-trophy"></i>
         <span class="links_name">Pemenang</span>
       </a>
       <span class="tooltip">Pemenang</span>
     </li>
     <li>
      <?php endif; ?>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/daftar">
        <i class='bx bx-task'></i>
         <span class="links_name">Data Peserta</span>
       </a>
       <span class="tooltip">Data Peserta</span>
     </li>
     <li>
        <?php endif; ?>
        <a href="<?php echo e(route('logout')); ?>">
            <i class='bx bx-log-out' id="log_out" ></i>
            <span class="links_name">Logout</span>
          </a>
          <span class="tooltip">Logout</span>
        </li>
        <li>
        
     </li>
    </ul>
  </div>
  <section class="home-section">
    <nav class="navbar navbar-expand-md navbar-dark shadow-sm" style="background-color: #539cd8; color: #fafafa">
      <div class="container">
          <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
              <?php echo e(config('app.name', 'Laravel')); ?>

          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
              aria-label="<?php echo e(__('Toggle navigation')); ?>">
              <span class="navbar-toggler-icon"></span>
          </button>
  
          <?php if(auth()->guard()->guest()): ?>
              <?php if(Route::has('login')): ?>
                  <li class="nav-item">
                      <a style="background-color: #FFFF0; class="nav-link"
                          href="<?php echo e(route('login')); ?>"><?php echo e(__('LOGIN')); ?></a>
                  </li>
              <?php endif; ?>
              <?php if(Route::has('register')): ?>
                  <li class="nav-item">
                      <a style="background-color: #FFFF0; class="nav-link"
                          href="<?php echo e(route('register')); ?>"><?php echo e(__('REGISTER')); ?></a>
                  </li>
              <?php endif; ?>
          <?php else: ?>
              <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                  data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                  <?php echo e(Auth::user()->name); ?>

              </a>
  
              <?php echo csrf_field(); ?>
          </div>
          </li>
      <?php endif; ?>
      </ul>
  </div>
  </div>
  </nav>
  
    <h1 class="text-center mt-4">Data Perlombaan</h1>
  
    <div class="container">
        <div class="row justify-content-center">
        <div class="col-9">
                <br>
                <a href="/tambahdata" class="btn btn-outline-success">Tambah+</a>
                <div class="row">
                    <div class="row justify-content-center">
                        <div class=" mt-4 mb-4">
                            <form action="/datalomba" method="get">
                                <div class="input-group">
                                    <label for="search" class="d-block mr-2"></label>
                                    <input type="text" class="form-control" name="search"
                                        placeholder="Masukkan keyword">
                                    <button class="btn btn-outline-success" type="submit">Search</button>
                                </div>
                            </form>
                            <?php if($manage = Session::get('success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e($manage); ?>

                                </div>
                            <?php endif; ?>
                            <div class="row justify-content-center">
                                <div class="col-10 mt-4 mb-4">
                                    <div class="card">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th scope="col">No</th>
                                                    <th scope="col">Foto</th>
                                                    <th scope="col">Nama Lomba</th>
                                                    <th scope="col">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $no = 1;
                                                ?>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($index + $data->firstItem()); ?></th>
                                                        <td>
                                                            <img src="<?php echo e(asset('fotolomba/' . $row->foto)); ?>" alt=""
                                                                style="width:50px;">
                                                        </td>
                                                        <td><?php echo e($row->judul); ?></td>

                                                        <td>
                                                            <a href="/detail/<?php echo e($row->id); ?>"
                                                                class="btn btn-outline-warning"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-journal-check" viewBox="0 0 16 16">
                                                                    <path fill-rule="evenodd" d="M10.854 6.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 8.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
                                                                    <path d="M3 0h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-1h1v1a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v1H1V2a2 2 0 0 1 2-2z"/>
                                                                    <path d="M1 5v-.5a.5.5 0 0 1 1 0V5h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1H1zm0 3v-.5a.5.5 0 0 1 1 0V8h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1H1zm0 3v-.5a.5.5 0 0 1 1 0v.5h.5a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1H1z"/>
                                                                  </svg> Detail</a>
                                                            <a href="/tampilkandata/<?php echo e($row->id); ?>"
                                                                class="btn btn-outline-primary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                                                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                                                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                                                  </svg> Edit</a>
                                                            <form action="/hapus/<?php echo e($row->id); ?>" method="post"
                                                                class="d-inline">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('delete'); ?>
                                                                <button type="submit" class="btn btn-outline-danger"
                                                                    data-id="<?php echo e($row->id); ?>"
                                                                    onclick="return confirm('Are you sure?')"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
                                                                        <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"/>
                                                                      </svg> Delete</button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    </div>
                                    <?php echo e($data->links()); ?>

                                </div>
                           
</section>
  <script>
  let sidebar = document.querySelector(".sidebar");
  let closeBtn = document.querySelector("#btn");
  let searchBtn = document.querySelector(".bx-search");

  closeBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("open");
    menuBtnChange();//calling the function(optional)
  });

  searchBtn.addEventListener("click", ()=>{ // Sidebar open when you click on the search iocn
    sidebar.classList.toggle("open");
    menuBtnChange(); //calling the function(optional)
  });

  // following are the code to change sidebar button(optional)
  function menuBtnChange() {
   if(sidebar.classList.contains("open")){
     closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
   }else {
     closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
   }
  }
  </script>
    

    
                            <!-- Optional JavaScript; choose one of the two! -->

                            <!-- Option 1: Bootstrap Bundle with Popper -->
                            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
                                integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
                            </script>


                            <!-- Option 2: Separate Popper and Bootstrap JS -->
                            <!--
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
            integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
            integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
        </script>
        -->
                            </body>


                        </div>
                    </div>
                </div>
            </div>

            </html>
       
<?php /**PATH C:\simeet\resources\views/datalomba.blade.php ENDPATH**/ ?>