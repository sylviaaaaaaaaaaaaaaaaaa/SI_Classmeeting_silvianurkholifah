<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!----======== CSS ======== -->
    
    <link rel="stylesheet" href="/css/app.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/trix.css')); ?>">
        <script type="text/javascript" src="/js/trix.js"></script>
        <link rel="stylesheet" type="text/css" href="https://unpkg.com/trix@2.0.0/dist/trix.css">
        <script type="text/javascript" src="https://unpkg.com/trix@2.0.0/dist/trix.umd.min.js"></script>
    <!----===== Boxicons CSS ===== -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<div class="sidebar">
    <div class="logo-details">

        <i class='bx bxl-stripe'></i>
        <i class='bx bx-menu' id="btn"></i>
    </div>
    <ul class="nav-list">
        <li>
            <i class='bx bx-search'></i>
            <input type="text" placeholder="Search...">
            <span class="tooltip">Search</span>
        </li>
        <li>
            <a href="/home">
                <i class='bx bx-grid-alt'></i>
                <span class="links_name">Dashboard</span>
            </a>
            <span class="tooltip">Dashboard</span>
        </li>
        <li>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/user">
                    <i class='bx bx-user'></i>
                    <span class="links_name">User</span>
                </a>
                <span class="tooltip">User</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/datalomba">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Data Lomba</span>
                </a>
                <span class="tooltip">Data Lomba</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'siswa'): ?>
                <a href="/lombasiswa">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Data Lomba</span>
                </a>
                <span class="tooltip">Data Lomba</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/datajadwal">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Data Jadwal</span>
                </a>
                <span class="tooltip">Data Jadwal</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'siswa'): ?>
                <a href="/tambahpeserta">
                    <i class='bx bx-cart-alt'></i>
                    <span class="links_name">Pendaftaran</span>
                </a>
                <span class="tooltip">Pendaftaran</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'siswa'): ?>
                <a href="/jadwalsiswa">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Data Jadwal</span>
                </a>
                <span class="tooltip">Data Jadwal</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/pemenang">
                    <i class="bi bi-trophy"></i>
                    <span class="links_name">Pemenang</span>
                </a>
                <span class="tooltip">Pemenang</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'siswa'): ?>
                <a href="/pemenangsiswa">
                    <i class="bi bi-trophy"></i>
                    <span class="links_name">Pemenang</span>
                </a>
                <span class="tooltip">Pemenang</span>
        </li>
        <li>
            <?php endif; ?>
            <?php if(auth()->user()->level == 'admin'): ?>
                <a href="/daftar">
                    <i class='bx bx-task'></i>
                    <span class="links_name">Data Peserta</span>
                </a>
                <span class="tooltip">Data Peserta</span>
        </li>
        <li>
            <?php endif; ?>
            <a href="<?php echo e(route('logout')); ?>">
                <i class='bx bx-log-out' id="log_out"></i>
                <span class="links_name">Logout</span>
            </a>
            <span class="tooltip">Logout</span>
        </li>
        <li>

        </li>
    </ul>
</div>
<section class="home-section">
    <nav class="navbar navbar-expand-md navbar-dark shadow-sm" style="background-color: #539cd8; color: #fafafa">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(config('app.name', 'Laravel')); ?>

            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('login')): ?>
                    <li class="nav-item">
                        <a style="background-color: #FFFF0; class="nav-link"
                            href="<?php echo e(route('login')); ?>"><?php echo e(__('LOGIN')); ?></a>
                    </li>
                <?php endif; ?>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a style="background-color: #FFFF0; class="nav-link"
                            href="<?php echo e(route('register')); ?>"><?php echo e(__('REGISTER')); ?></a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?>

                </a>
    
                <?php echo csrf_field(); ?>
            </div>
            </li>
        <?php endif; ?>
        </ul>
    </div>
    </div>
    </nav>
    <h1 class="text-center mb-4"> Edit Data Perlombaan</h1>

    <div class="container">
        <div class="row justify-content-center">

            <div class="card-body">
                <form action="/updatedata/<?php echo e($data->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-1">
                        <label for="exampleInputEmail1" class="form-label">Nama Lomba</label>
                        <input type="text" name="judul" class="form-control  <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="exampleInputEmail1" aria-describedby="emailHelp"
                            value="<?php echo e(old('judul', $data->judul)); ?>">
                        <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="juklak_juknis" class="form-label">Juklak Juknis</label>
                        <input id="juklak_juknis" type="hidden" name="juklak_juknis" required
                            value="<?php echo e(old('juklak_juknis', $data->juklak_juknis)); ?>"
                            class=" <?php $__errorArgs = ['juklak_juknis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        is_invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <trix-editor input="juklak_juknis"></trix-editor>
                        <?php $__errorArgs = ['juklak_juknis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-1">
                        <label for="exampleInputEmail1" class="form-label">kontak</label>
                        <input type="number" name="kontak"
                            class="form-control <?php $__errorArgs = ['kontak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputEmail1"
                            aria-describedby="emailHelp"value="<?php echo e(old('kontak', $data->kontak)); ?>">
                        <?php $__errorArgs = ['kontak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-1">
                        <label for="exampleInputEmail1" class="form-label">Foto</label>
                        <input type="file" name="foto" class="form-control <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="exampleInputEmail1" aria-describedby="emailHelp"
                            value="<?php echo e(old('foto', $data->foto)); ?>">
                        <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn btn-primary">Edit</button>
                    <a href="/datalomba" class="btn btn-warning">Kembali</a>
                </form>
            </div>
        </div>
    </div>

    </div>
    </div>
</section>
<script>
    let sidebar = document.querySelector(".sidebar");
    let closeBtn = document.querySelector("#btn");
    let searchBtn = document.querySelector(".bx-search");

    closeBtn.addEventListener("click", () => {
        sidebar.classList.toggle("open");
        menuBtnChange(); //calling the function(optional)
    });

    searchBtn.addEventListener("click", () => { // Sidebar open when you click on the search iocn
        sidebar.classList.toggle("open");
        menuBtnChange(); //calling the function(optional)
    });

    // following are the code to change sidebar button(optional)
    function menuBtnChange() {
        if (sidebar.classList.contains("open")) {
            closeBtn.classList.replace("bx-menu", "bx-menu-alt-right"); //replacing the iocns class
        } else {
            closeBtn.classList.replace("bx-menu-alt-right", "bx-menu"); //replacing the iocns class
        }
    }
</script>


<!-- Optional JavaScript; choose one of the two! -->

<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>

<!-- Option 2: Separate Popper and Bootstrap JS -->
<!--
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
            integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
            integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
        </script>
        -->
</body>

</html>
<?php /**PATH C:\simeet\resources\views/tampildata.blade.php ENDPATH**/ ?>