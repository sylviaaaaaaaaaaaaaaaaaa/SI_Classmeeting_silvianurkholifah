<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!----======== CSS ======== -->
    <link rel="stylesheet" href="css/app.css">

    <!----===== Boxicons CSS ===== -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<div class="sidebar">
    <div class="logo-details">
        <i class='bx bxl-stripe'></i>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
          <i class='bx bx-search' ></i>
         <input type="text" placeholder="Search...">
         <span class="tooltip">Search</span>
      </li>
      <li>
        <a href="/home">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
      <li>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/user">
         <i class='bx bx-user' ></i>
         <span class="links_name">User</span>
       </a>
       <span class="tooltip">User</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/datalomba">
        <i class='bx bx-book'></i>
         <span class="links_name">Data Lomba</span>
       </a>
       <span class="tooltip">Data Lomba</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
       <a href="/lombasiswa">
        <i class='bx bx-book'></i>  
         <span class="links_name">Data Lomba</span>
       </a>
       <span class="tooltip">Data Lomba</span>
     </li>
     <li>

      <?php endif; ?>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/datajadwal">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Data Jadwal</span>
       </a>
       <span class="tooltip">Data Jadwal</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
        <a href="/tambahpeserta">
            <i class='bx bx-clipboard'></i>
          <span class="links_name">Pendaftaran</span>
        </a>
        <span class="tooltip">Pendaftaran</span>
      </li>
      <li>
         <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
       <a href="/jadwalsiswa">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Data Jadwal</span>
       </a>
       <span class="tooltip">Data Jadwal</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/pemenang">
        <i class="bi bi-trophy"></i>
         <span class="links_name">Pemenang</span>
       </a>
       <span class="tooltip">Pemenang</span>
     </li>
     <li>
        <?php endif; ?>
        <?php if(auth()->user()->level == 'siswa'): ?>
       <a href="/pemenangsiswa">
        <i class="bi bi-trophy"></i>
         <span class="links_name">Pemenang</span>
       </a>
       <span class="tooltip">Pemenang</span>
     </li>
     <li>
      <?php endif; ?>
        <?php if(auth()->user()->level == 'admin'): ?>
       <a href="/daftar">
        <i class='bx bx-task'></i>
         <span class="links_name">Data Peserta</span>
       </a>
       <span class="tooltip">Data Peserta</span>
     </li>
     <li>
        <?php endif; ?>
        <a href="<?php echo e(route('logout')); ?>">
            <i class='bx bx-log-out' id="log_out" ></i>
            <span class="links_name" >Logout</span>
          </a>
          <span class="tooltip">Logout</span>
        </li>
        <li>
        
     </li>
    </ul>
  </div>
 <section class="home-section"> 
    <nav class="navbar navbar-expand-md navbar-dark shadow-sm" style="background-color: #539cd8; color: #fafafa">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(config('app.name', 'Laravel')); ?>

            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <?php if(auth()->guard()->guest()): ?>
                <?php if(Route::has('login')): ?>
                    <li class="nav-item">
                        <a style="background-color: #FFFF0; class="nav-link"
                            href="<?php echo e(route('login')); ?>"><?php echo e(__('LOGIN')); ?></a>
                    </li>
                <?php endif; ?>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item">
                        <a style="background-color: #FFFF0; class="nav-link"
                            href="<?php echo e(route('register')); ?>"><?php echo e(__('REGISTER')); ?></a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?>

                </a>
    
                <?php echo csrf_field(); ?>
            </div>
            </li>
        <?php endif; ?>
        </ul>
    </div>
    </div>
    </nav>
    <?php if($manage = Session::get('success')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e($manage); ?>

                                </div>
                            <?php endif; ?>
                            
                            <div class="row justify-content-center">
                                <div class="col-md-20">
                                    <h3 class="font-weight-bolder mb-0 px-4 col mt-4">
                                       
                                        <div class="card-body">
                                            <?php if(session('status')): ?>
                                                <div class="alert alert-success" role="alert">
                                                    <?php echo e(session('status')); ?>

                                                </div>
                                            <?php endif; ?>
                                            <img src="../images/ppp.jpeg" style="width: 20%">
                                            Hai, <?php echo e(Auth::user()->name); ?> welcome to simeet!
                                    </h3>
                                </div>
                            
    <div class="p-5">
        <div class="row p-24  mt-4">
    <div class="col-sm-4 col-md-4 " >
     <div class="card card-stats card-round bg-info ">
         <div class="card-body">
             <div class="row">
                 <div class="col-icon">
                 <div class="icon-big icon-primary bubble-shadow-small">
                     <i class='bx bx-book'></i>
                 </div>
             </div>
                 <div class="col col-stats ml-3 ml-sm-0">
                     <div class="numbers">
                         <div class="card-body  align-center">
                         <p class="card-category">Data Lomba</p>
                         <h4 class="card-title"><?php echo e($lomba); ?></h4>
                     </div>
             </div>
             </div>
         </div>
     </div>
    </div>
    </div>
    <div class="col-sm-4 col-md-4 mt-8" >
     <div class="card card-stats card-round bg-primary">
         <div class="card-body">
             <div class="row">
                 <div class="col-icon">
                 <div class="icon-big icon-primary bubble-shadow-small">
                     <i class='bx bx-task'></i>
                 </div>
             </div>
                 <div class="col col-stats ml-3 ml-sm-0">
                     <div class="numbers">
                         <div class="card-body align-center">
                         <p class="card-category">Data Peserta</p>
                         <h4 class="card-title"><?php echo e($daftar); ?></h4>
                     </div>
             </div>
             </div>
         </div>
     </div>
    </div>
    </div>
    <div class="col-sm-4 col-md-4 mt-8s" >
     <div class="card card-stats card-round bg-warning">
         <div class="card-body">
             <div class="row">
                 <div class="col-icon">
                 <div class="icon-big icon-primary bubble-shadow-small">
                      <i class='bx bx-user' ></i>
                 </div>
             </div>
                 <div class="col col-stats ml-3 ml-sm-0">
                     <div class="numbers">
                         <div class="card-body  align-center">
                         <p class="card-category">Data User</p>
                         <h4 class="card-title"><?php echo e($user); ?></h4>
                     </div>
             </div>
             </div>
         </div>
     </div>
    </div>
    </div>    
</div>     
 </div>
</div>
</div>
</div>
</div>
<br>
</section>
  <script>
  let sidebar = document.querySelector(".sidebar");
  let closeBtn = document.querySelector("#btn");
  let searchBtn = document.querySelector(".bx-search");

  closeBtn.addEventListener("click", ()=>{
    sidebar.classList.toggle("open");
    menuBtnChange();//calling the function(optional)
  });

  searchBtn.addEventListener("click", ()=>{ // Sidebar open when you click on the search iocn
    sidebar.classList.toggle("open");
    menuBtnChange(); //calling the function(optional)
  });

  // following are the code to change sidebar button(optional)
  function menuBtnChange() {
   if(sidebar.classList.contains("open")){
     closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");//replacing the iocns class
   }else {
     closeBtn.classList.replace("bx-menu-alt-right","bx-menu");//replacing the iocns class
   }
  }
  </script>
  
</html>


<?php /**PATH C:\simeet\resources\views/home.blade.php ENDPATH**/ ?>