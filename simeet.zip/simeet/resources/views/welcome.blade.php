<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Simeet</title>
    <link rel="stylesheet" href="{{ asset('css/home.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <section>
        <header>
            <h2>  <a href="#" class="logo">Simeet</a></h2>
            <div class="navigation">
                <a href="{{ url('/home') }}">Home</a>
        </header>
        <div class="content">
            <div class="info">
                <h2>Sistem Informasi <br><span>Classmeeting</span></h2>
                <p>Classmeeting adalah program kegiatan yang berisi berbagai ajang perlombaan dan dilakukan antar kelas.Classmeeting biasanya dilakukan setelah siswa menyelesaikan penilaian akhir semester (PAS) dan sebelum penerimaan rapor. </p>
                <a href="{{ route('login') }}" class="info-btn">Login</a>
            </div>
        </div>
       
    </section>
</body>
</html>