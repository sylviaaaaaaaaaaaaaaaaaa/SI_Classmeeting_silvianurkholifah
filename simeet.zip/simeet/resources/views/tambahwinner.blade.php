@extends('layouts.app')
@section('content')
    <!doctype html>
    <html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

        <title>Pemenang</title>
    </head>

    <body>
        <h1 class="text-center mb-4">Pemenang Lomba</h1>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-15 mt-4 mb-4">

                    <div class="row justify-content-center">
                        <div class="col-10">
                            <div class="card">
                                <div class="card-body">
                                    <form action="/insertwinner" method="POST" enctype="multipart/form-data">
                                        @csrf
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Foto</label>
                                            <input type="file" name="foto_lomba"
                                                class="form-control @error('foto_lomba') is-invalid @enderror"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="{{ old('foto_lomba') }}">
                                            @error('foto_lomba')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Nama Lomba</label>
                                            <input type="text" name="nama_perlombaan"
                                                class="form-control @error('nama_perlombaan') is-invalid @enderror"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="{{ old('nama_perlombaan') }}">
                                            @error('nama_perlombaan')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Winner 1</label>
                                            <input type="text" name="juara_satu"
                                                class="form-control  @error('juara_satu') is-invalid @enderror"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="{{ old('juara_satu') }}">
                                            @error('juara_satu')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Winner 2</label>
                                            <input type="text" name="juara_dua"
                                                class="form-control  @error('juara_dua') is-invalid @enderror"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="{{ old('juara_dua') }}">
                                            @error('juara_dua')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Winner 3</label>
                                            <input type="text" name="juara_tiga"
                                                class="form-control  @error('juara_tiga') is-invalid @enderror"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="{{ old('juara_tiga') }}">
                                            @error('juara_tiga')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>

                                        <button type="submit" class="btn btn-primary">Tambah</button>
                                        <a href="/pemenang" class="btn btn-warning">Kembali</a>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- Optional JavaScript; choose one of the two! -->

                <!-- Option 1: Bootstrap Bundle with Popper -->
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
                    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
                </script>

                <!-- Option 2: Separate Popper and Bootstrap JS -->
                <!--
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
            integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
            integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
        </script>
        -->
    </body>

    </html>
    </div>
    </div>
@endsection
