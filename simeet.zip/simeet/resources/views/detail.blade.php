 <!DOCTYPE html>
 <html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Detail</title>
    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!----======== CSS ======== -->
    <link rel="stylesheet" href="css/app.css">

    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
 </head>
 <body>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-9">
                <div class="row">
                    <div class=" mt-5 mb-5">
                <h2>Detail Lomba</h2> 
                <div class="card mb-4" style="max-width: 540px;">
      <div class="row g-0">
        <div class="col-md-4">
            <img src="/fotolomba/{{ $data->foto }}" class="img-fluid rounded-start" alt="...">
        </div> 
        <div class="col-md-8">
          <div class="card-body">
            <p class="card-title"><b>nama lomba: </b>{{ $data->judul }}</p>
            <p class="card-text"><b>penanggung jawab : </b>0{{ $data->kontak }}</p>
            <p class="card-text"><b>juklak juknis : </b>{!! $data->juklak_juknis !!}</p>

            <br><br>
            <a href="/datalomba" class="btn btn-outline-success">Kembali Ke Data Lomba</a>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
          
        </body>
        </html>        
