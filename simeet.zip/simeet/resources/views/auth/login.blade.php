<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SIMEET | Login</title>
    <link href="{{ asset('css/app.css') }}" rel="styleshet">
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <div class="container">
        <input type="checkbox" id="flip">
        <div class="cover">
            <div class="front">
                <img src="images/ppp.jpeg" alt="">
                <div class="text">
                </div>
            </div>
            <div class="back">
                <img class="backImg" src="/images/ppp.jpeg" alt="">
                <div class="text">
                    <span class="text-1">Halo!<br> BUAT AKUN</span>
                    <span class="text-2">Silahkan Membuat akun terlebih dahulu!</span>
                </div>
            </div>
        </div>
        <div class="forms">
            <div class="form-content">
                <div class="login-form">
                    <div class="title">AYO BUAT AKUN!</div>
                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                        <div class="input-boxes">
                            <div class="input-box">
                                <div class="col-md-6" style="width:500px;">
                                    <i class="fas fa-envelope"></i>
                                    <input id="email" type="email"
                                        class="form-control @error('email') is-invalid @enderror" name="email"
                                        value="{{ old('email') }}" placeholder="Masukkan E-mail" autofocus>
                                    @error('email')
                                        <div class="invalid-feedback text-red-500">{{ 'Email Wajib diisi!' }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="input-box">
                                <div class="col-md-6 my-2" style="width:500px;">
                                    <i class="fas fa-lock"></i>
                                    <input id="password" type="password"
                                        class="form-control @error('password') is-invalid @enderror" name="password"
                                        placeholder="Masukkan Password" autofocus> @error('password')
                                        <div class="invalid-feedback text-red-500">{{ 'Password harus diisi!' }}</div>
                                    @enderror
                                </div>
                            </div>
                            <div class="text"><a href="password/reset">Forgot password?</a></div>
                            <div class="button input-box">
                                <input type="submit" value="Submit">
                            </div>
                            <p class="message">Belum Mempunyai Akun? <a href="/register">Registrasi</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>