
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!----======== CSS ======== -->
    {{-- <link rel="stylesheet" href="css/app.css"> --}}
    <link rel="stylesheet" href="/css/app.css">
    <link rel="stylesheet" href="{{ asset('css/trix.css') }}">
        <script type="text/javascript" src="/js/trix.js"></script>
        <link rel="stylesheet" type="text/css" href="https://unpkg.com/trix@2.0.0/dist/trix.css">
        <script type="text/javascript" src="https://unpkg.com/trix@2.0.0/dist/trix.umd.min.js"></script>
    <!----===== Boxicons CSS ===== -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<div class="sidebar">
    <div class="logo-details">

        <i class='bx bxl-stripe'></i>
        <i class='bx bx-menu' id="btn"></i>
    </div>
    <ul class="nav-list">
        <li>
            <i class='bx bx-search'></i>
            <input type="text" placeholder="Search...">
            <span class="tooltip">Search</span>
        </li>
        <li>
            <a href="/home">
                <i class='bx bx-grid-alt'></i>
                <span class="links_name">Dashboard</span>
            </a>
            <span class="tooltip">Dashboard</span>
        </li>
        <li>
            @if (auth()->user()->level == 'admin')
                <a href="/user">
                    <i class='bx bx-user'></i>
                    <span class="links_name">User</span>
                </a>
                <span class="tooltip">User</span>
        </li>
        <li>
            @endif
            @if (auth()->user()->level == 'admin')
                <a href="/datalomba">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Data Lomba</span>
                </a>
                <span class="tooltip">Data Lomba</span>
        </li>
        <li>
            @endif
            @if (auth()->user()->level == 'siswa')
                <a href="/lombasiswa">
                    <i class='bx bx-book'></i>
                    <span class="links_name">Data Lomba</span>
                </a>
                <span class="tooltip">Data Lomba</span>
        </li>
        <li>
            @endif
            @if (auth()->user()->level == 'admin')
                <a href="/datajadwal">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Data Jadwal</span>
                </a>
                <span class="tooltip">Data Jadwal</span>
        </li>
        <li>
            @endif
            @if (auth()->user()->level == 'siswa')
                <a href="/tambahpeserta">
                    <i class='bx bx-cart-alt'></i>
                    <span class="links_name">Pendaftaran</span>
                </a>
                <span class="tooltip">Pendaftaran</span>
        </li>
        <li>
            @endif
            @if (auth()->user()->level == 'siswa')
                <a href="/jadwalsiswa">
                    <i class='bx bx-pie-chart-alt-2'></i>
                    <span class="links_name">Data Jadwal</span>
                </a>
                <span class="tooltip">Data Jadwal</span>
        </li>
        <li>
            @endif
            @if (auth()->user()->level == 'admin')
                <a href="/pemenang">
                    <i class="bi bi-trophy"></i>
                    <span class="links_name">Pemenang</span>
                </a>
                <span class="tooltip">Pemenang</span>
        </li>
        <li>
            @endif
            @if (auth()->user()->level == 'siswa')
                <a href="/pemenangsiswa">
                    <i class="bi bi-trophy"></i>
                    <span class="links_name">Pemenang</span>
                </a>
                <span class="tooltip">Pemenang</span>
        </li>
        <li>
            @endif
            @if (auth()->user()->level == 'admin')
                <a href="/daftar">
                    <i class='bx bx-task'></i>
                    <span class="links_name">Data Peserta</span>
                </a>
                <span class="tooltip">Data Peserta</span>
        </li>
        <li>
            @endif
            <a href="{{ route('logout') }}">
                <i class='bx bx-log-out' id="log_out"></i>
                <span class="links_name">Logout</span>
            </a>
            <span class="tooltip">Logout</span>
        </li>
        <li>

        </li>
    </ul>
</div>
<section class="home-section">
    <nav class="navbar navbar-expand-md navbar-dark shadow-sm" style="background-color: #539cd8; color: #fafafa">
        <div class="container">
            <a class="navbar-brand" href="{{ url('/') }}">
                {{ config('app.name', 'Laravel') }}
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="{{ __('Toggle navigation') }}">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            @guest
                @if (Route::has('login'))
                    <li class="nav-item">
                        <a style="background-color: #FFFF0; class="nav-link"
                            href="{{ route('login') }}">{{ __('LOGIN') }}</a>
                    </li>
                @endif
                @if (Route::has('register'))
                    <li class="nav-item">
                        <a style="background-color: #FFFF0; class="nav-link"
                            href="{{ route('register') }}">{{ __('REGISTER') }}</a>
                    </li>
                @endif
            @else
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    {{ Auth::user()->name }}
                </a>
                @csrf
            </div>
            </li>
        @endguest
        </ul>
    </div>
    </div>
    </nav>
        <h1 class="text-center mb-4"> Edit Data Jadwal</h1>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-15 mt-4 mb-4">

                    <div class="row justify-content-center">
                        <div class="col-10">
                            <div class="card">
                                <div class="card-body">
                                    <form action="/update/{{ $data->id }}" method="POST" enctype="multipart/form-data">
                                        @csrf
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Nama Lomba</label>
                                            <input type="text" name="nama_lomba"
                                                class="form-control @error('nama_lomba') is-invalid @enderror"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="{{ old('nama_lomba', $data->nama_lomba) }}">
                                            @error('nama_lomba')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Kelas</label>
                                            <input type="text" name="nama_kelas"
                                                class="form-control @error('nama_kelas') is-invalid @enderror"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="{{ old('nama_kelas', $data->nama_kelas) }}">
                                            @error('nama_kelas')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Hari/Tanggal</label>
                                            <input type="text" name="hari"
                                                class="form-control @error('hari') is-invalid @enderror"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="{{ old('hari', $data->hari) }}">
                                            @error('hari')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleInputEmail1" class="form-label">Waktu</label>
                                            <input type="text" name="waktu"
                                                class="form-control  @error('waktu') is-invalid @enderror"
                                                id="exampleInputEmail1" aria-describedby="emailHelp"
                                                value="{{ old('waktu', $data->waktu) }}">
                                            @error('waktu')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>

                                        <button type="submit" class="btn btn-outline-primary"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-download" viewBox="0 0 16 16">
                                            <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
                                            <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/>
                                          </svg> Edit</button>
                                        <a href="/datajadwal" class="btn btn-outline-warning"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-box-arrow-left" viewBox="0 0 16 16">
                                            <path fill-rule="evenodd" d="M6 12.5a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v2a.5.5 0 0 1-1 0v-2A1.5 1.5 0 0 1 6.5 2h8A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 5 12.5v-2a.5.5 0 0 1 1 0v2z"/>
                                            <path fill-rule="evenodd" d="M.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L1.707 7.5H10.5a.5.5 0 0 1 0 1H1.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3z"/>
                                          </svg> Kembali</a>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <script>
                let sidebar = document.querySelector(".sidebar");
                let closeBtn = document.querySelector("#btn");
                let searchBtn = document.querySelector(".bx-search");
            
                closeBtn.addEventListener("click", () => {
                    sidebar.classList.toggle("open");
                    menuBtnChange(); //calling the function(optional)
                });
            
                searchBtn.addEventListener("click", () => { // Sidebar open when you click on the search iocn
                    sidebar.classList.toggle("open");
                    menuBtnChange(); //calling the function(optional)
                });
            
                // following are the code to change sidebar button(optional)
                function menuBtnChange() {
                    if (sidebar.classList.contains("open")) {
                        closeBtn.classList.replace("bx-menu", "bx-menu-alt-right"); //replacing the iocns class
                    } else {
                        closeBtn.classList.replace("bx-menu-alt-right", "bx-menu"); //replacing the iocns class
                    }
                }
            </script>
                <!-- Optional JavaScript; choose one of the two! -->

                <!-- Option 1: Bootstrap Bundle with Popper -->
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
                    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
                </script>

                <!-- Option 2: Separate Popper and Bootstrap JS -->
                <!--
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
            integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous">
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
            integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous">
        </script>
        -->
    </body>

    </html>
    </div>
    </div>

